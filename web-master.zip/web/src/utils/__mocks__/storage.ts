export const storage = {
  loadJooxUUID: jest.fn(),
  saveJooxUUID: jest.fn(),
};
