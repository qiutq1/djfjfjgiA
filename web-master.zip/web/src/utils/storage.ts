import storageFactory from './storage/StorageFactory';

export const storage = storageFactory();
